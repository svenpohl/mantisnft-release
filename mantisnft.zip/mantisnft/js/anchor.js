 
let session_anchor;
 

function wallet_login_anchor()
{

if (current_wallet == wallet_anchor) return;
 

 
        // login and store session if sucessful
        
            link.login( mantisnft_appname ).then((result) => {
                session_anchor = result.session;
                eosio_account = session_anchor.auth.actor;
                    document.getElementById('mantis_accountname').innerHTML = eosio_account;
                    current_wallet = wallet_anchor;
                    mantisnft_wallet_login();
                     }) 
                
      

        
        
        


} // wallet_login_anchor()



 

function mantisnft_wallet_anchor_autologin()
{
if (current_wallet == wallet_anchor) return;


 

 link.restoreSession(mantisnft_appname).then((result) => {
                session_anchor = result
                if (session_anchor) {
                   eosio_account = session_anchor.auth.actor;
                    document.getElementById('mantis_accountname').innerHTML = eosio_account;
                    current_wallet = wallet_anchor;
                    mantisnft_wallet_login();
                   }
            })
            
 
} // mantisnft_wallet_anchor_autologin



function wallet_logout_anchor()
{
 

if (current_wallet != wallet_anchor) return;


       eosio_account = "";
current_wallet = 0;
 

 document.getElementById('mantis_accountname').innerHTML = eosio_account + "";
 
            session_anchor.remove()
            
 
 

} // wallet_logout_anchor


function verify_action_anchor()
{
 

 
            const action = {
                account: 'signinsignin',
                name: 'signin',
                 authorization: [{
            actor: eosio_account,
            permission: 'active',
            
            }],
                data: {
                    signer: eosio_account,                  
                    memo: mantisnft_hashtoverify
                }
            }
            session_anchor.transact({action}).then((result) => {
 
            })
            
 

} // verify_action_anchor




//
// Action for claimdropbox-claim
//
function claimdropbox_claim_anchor( var_recipient, var_dropid )
{
 
 const action = {
                account: 'claimdropbox',
                name: 'claim',
                authorization: [{
                actor: eosio_account,
                permission: 'active',            
                }],
                data: {
                      recipient: var_recipient,                  
                      dropid: var_dropid
                      }
                }
                session_anchor.transact({action}).then((result) => {
 
                })
 

} // claimdropbox_claim_anchor



 
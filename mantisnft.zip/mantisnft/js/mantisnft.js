

let current_wallet  = 0; 
let wallet_waxcloud = 1; 
let wallet_anchor   = 2; 

let eosio_account   = "";
let mantisnft_hashtoverify = "";

let mantisnft_verified       = 0; // status
let mantisnft_contentloaded = 0; // status

function doit3()
{
alert("doit 3 NFT");
}


function doittest()
{

url = mantisnft_url + "worker.php";

 




eosio_accountname = "alf";

var jsonparam = JSON.stringify( {account: eosio_accountname, app: mantisnft_appname } ); 

 ret = mantisnft_readurl(url, jsonparam); 

 document.getElementById('testoutput').innerHTML = ret;  
 
}




function mantisnft_readurl(url, jsonparam) 
{

 try {
var xhr = new XMLHttpRequest(); 
var fd = new FormData(); 
xhr.open('POST', url, false); 

 
var data2 = jsonparam ;
  
xhr.send(data2); 


 

var response = xhr.responseText; 

return(response);
      } catch (e)
         {
         console.log("Connection failed, grabbing local");
         return '[]';
         }
} 
 
 
function mantisnft_setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
 
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}

function mantisnft_getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

function mantisnft_eraseCookie(name) {   
    document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}





//
// Wallet beginn --------
//

function mantisnft_wallet_login()
{

mantisnft_setCookie('mantiswallet',current_wallet,30);

 
   {
   document.getElementById('eosio_login_area').style.visibility = "hidden";
   document.getElementById('eosio_logout_area').style.visibility = "visible";

   document.getElementById('mantis_verify').style.visibility = "visible";
   document.getElementById('mantis_verify').style.height = "";         
   }
   
   /*
    
   */
  
   //
   // Get hash fast
   // 
   url = mantisnft_url + "worker.php?cmd=gethash"; 
 
   var jsonparam = JSON.stringify( {  account: eosio_account,  app: mantisnft_appname   } ); 
   var xmlhttp = new XMLHttpRequest();   
   xmlhttp.timeout = 7000;  
   xmlhttp.open('POST', url);
                                                    
   xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

   xmlhttp.onreadystatechange = function() {
   if (this.readyState == 4 && this.status == 200) 
      {
      response = this.responseText;
                                   
      var response_array = JSON.parse(this.responseText);                                 
      var hash = response_array['hash'];
                                               
      mantisnft_hashtoverify = hash;                                                                                              
      console.log("mantisnft_hashtoverify: "+mantisnft_hashtoverify);
      } // if
      }; // function()
    xmlhttp.send(jsonparam);
 
   
} // mantisnft_wallet_login();


 


function mantisnft_wallet_logout()
{


 
 
if (current_wallet == wallet_waxcloud)  wallet_logout_waxcloud();
if (current_wallet == wallet_anchor)    wallet_logout_anchor();


mantisnft_eraseCookie('mantiswallet');


 document.getElementById('nft_content').innerHTML = "";
mantisnft_contentloaded = 0;     
mantisnft_verified = 0;    


 document.getElementById('nft_info_div').style.visibility = "visible";
 document.getElementById('nft_info_div').style.height     = "";
   
  
   {
   document.getElementById('eosio_login_area').style.visibility = "visible";
   document.getElementById('eosio_logout_area').style.visibility = "hidden";
   document.getElementById('eosio_logout_area').style.height = "0px";

   document.getElementById('mantis_verify').style.visibility = "hidden";
   document.getElementById('mantis_verify').style.height = "0px";
   
   
   
  
   
   }
   
} // manitsnft_wallet_logout();


 



 






function mantisnft_wallet_autologin()
{
 

var mantiswallet =  mantisnft_getCookie('mantiswallet'); 
 
 
 
if (mantiswallet == wallet_waxcloud)  mantisnft_wallet_waxcloud_autologin();
if (mantiswallet == wallet_anchor)    mantisnft_wallet_anchor_autologin();
 

  
   
}
 

//
// Wallet end --------
//






function mantisnft_verify()
{

if (mantisnft_hashtoverify == "") 
   {
   alert('Verify-hash is missing - please wait a few seconds or reload this page!');
   return;
   } 

if (current_wallet == wallet_waxcloud) verify_action_waxcloud();
if (current_wallet == wallet_anchor)   verify_action_anchor();

 
}

 
  


 
  

 


 
//
// Thread ---
//

var debugcnt = 0;



function mantisnft_thread()
{

 
console.log("cnt " + debugcnt + " mantisnft_verified:"+mantisnft_verified+ " l:" + eosio_account );



if (eosio_account == "")
   {
   document.getElementById('mantis_verify').style.visibility = "hidden";
   document.getElementById('mantis_verify').style.height = "0px";
   }


if (
   mantisnft_verified == 0 && 
   eosio_account != ""
//   && 0
   )
   {
   // Check if verified
   console.log("Check if verified");
   url = mantisnft_url + "worker.php?cmd=checktx"; 
 
   var jsonparam = JSON.stringify( {  account: eosio_account,  app: mantisnft_appname   } ); 

 


 
                           var xmlhttp = new XMLHttpRequest();   
                           xmlhttp.timeout = 7000;  
                           xmlhttp.open('POST', url);
                                                    
                           xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


                           xmlhttp.onreadystatechange = function() {
                              if (this.readyState == 4 && this.status == 200) 
                                 {
                                  response = this.responseText;
                                   
                                  
                                  // set verified status 
                                  var response_array = JSON.parse(this.responseText);                                 
                                  var hash = response_array['hash'];
                                  mantisnft_verified = response_array['checked'];
                                  mantisnft_hashtoverify = hash;
                                 // mantisnft_verified = checked;                                  
                                  if (mantisnft_verified == 1) 
                                     {
  
                                     document.getElementById('mantis_checkmark').innerHTML = "&check;";    
                                     
                                     document.getElementById('mantis_verify').style.visibility = 'hidden';
                                     document.getElementById('mantis_verify').style.height = '1px';
                                     
                                                                     
                                     }
                                  if (mantisnft_verified == 0) 
                                     {
 
                                     document.getElementById('mantis_checkmark').innerHTML = "&cross;";

                                     document.getElementById('mantis_verify').style.visibility = 'visible';
                                     document.getElementById('mantis_verify').style.height = '';

                                     }
   
                                      
                                 } // if
                           }; // function()
                           xmlhttp.send(jsonparam);
 

   } // if (mantisnft_verified == 0)


if (mantisnft_verified == 1 && mantisnft_contentloaded == 0 )
   {
   // Try to load content
   
 
   
   console.log("Try to load content...");
  

url = mantisnft_url + "worker.php?cmd=loadcontent";
   
 var jsonparam = JSON.stringify( {  account: eosio_account , postid: mantisnft_post_id, app: mantisnft_appname   } ); 

 
  
  
                           var xmlhttp = new XMLHttpRequest();   
                           xmlhttp.timeout = 7000;  
                           xmlhttp.open('POST', url);
                                                    
                           xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


                           xmlhttp.onreadystatechange = function() {
                              if (this.readyState == 4 && this.status == 200) 
                                 {
                                  response = this.responseText;
                                   
                                  console.log("Response:");
                                  console.log( response );
                                  // set content 
                                  thecontent = "";
                                  if ( response == "{error_verified}") 
                                     {
                                     thecontent = "Not verified!";
  
                                      
                              
                                     } else
                                  if ( response == "{error_nft}") 
                                     {
                                     thecontent = ""+mantisnft_no_nft_message;
                                     } else
                                       {
                                       mantisnft_contentloaded = 1;
          
                                       document.getElementById('nft_info_div').style.visibility = "hidden";
                                       document.getElementById('nft_info_div').style.height     = "0px";
                                       document.getElementById('nft_info_div').style.Maxheight     = "0px";

                                       document.getElementById('nft_content').style.visibility = "visible";
                                       document.getElementById('nft_content').style.height     = "";

                                       thecontent = response;
                                       
                                       }
                                       
                                      document.getElementById('nft_content').innerHTML = "" + thecontent;

   
   
                                      
                                 } // if
                           }; // function()
                           xmlhttp.send(jsonparam); 



   } // if (mantisnft_verified == 1 && mantisnft_contentloaded == 0 )






 

  
   

  
 debugcnt++;
 // // e 
    
 
var zeit = setTimeout("mantisnft_thread()", 4000);
} //// eosiomantis_thread



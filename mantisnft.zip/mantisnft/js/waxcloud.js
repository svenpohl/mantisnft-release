
let waxcloud = null;


let userAccount_anchor;
 
async function wallet_login_cloud()
{

 if (  current_wallet == wallet_waxcloud ) return;

  waxcloud = new waxjs.WaxJS('https://chain.wax.io', null, null, false);
 
 console.log("wallet_login_cloud");
    
        
        try {
          
              eosio_account = await waxcloud.login();
            let pubKeys = waxcloud.pubKeys;
             console.log("wallet_login_cloud 2");
       
           
              document.getElementById('mantis_accountname').innerHTML = eosio_account;
             
              current_wallet  = wallet_waxcloud; 
 
              
                    mantisnft_wallet_login();
                    
            
        
        } catch (e) {
                     console.log(e);
           
        }
   
        
        


} // wallet_login_cloud()


async function mantisnft_wallet_waxcloud_autologin()
{
 if (  current_wallet == wallet_waxcloud ) return;

  waxcloud = new waxjs.WaxJS('https://chain.wax.io', null, null, false);
 
 console.log("Autologin WAX Cloud");
 
        let isAutoLoginAvailable = await waxcloud.isAutoLoginAvailable();
        if (isAutoLoginAvailable) 
        
          {
          
          
             eosio_account = await waxcloud.login();
            let pubKeys = waxcloud.pubKeys;
            
 
           
              document.getElementById('mantis_accountname').innerHTML = eosio_account;
                 current_wallet  = wallet_waxcloud; 
                    mantisnft_wallet_login();
                    
            
        }
        else {
            console.log("No autologin");
        }
    
}





async function wallet_logout_waxcloud()
{

 
  waxcloud = new waxjs.WaxJS('https://chain.wax.io', null, null, true);
  
 if (  current_wallet != wallet_waxcloud ) return;
 

console.log(waxcloud);

console.log("logout Cloud");

 try {
console.log("logout Cloud try 1");

           
            waxcloud = null;
 
            
console.log("logout Cloud try 2");
            
          eosio_account = "";
current_wallet = 0;
 

console.log("logout Cloud try 3");

 document.getElementById('mantis_accountname').innerHTML = eosio_account + "";
 

 
        } catch (e) {
        console.log(e);
 
        }



} // wallet_logout_cloud()


async function verify_action_waxcloud()
{
  



    if(!waxcloud.api) {
         return document.getElementById('response').append('* Login first *');
      
    }

    try {
        const result = await waxcloud.api.transact({
        actions: [
        {
             account: 'signinsignin',
                name: 'signin',
                 authorization: [{
            actor: eosio_account,
            permission: 'active',
            
            }],
            data: {
                    signer: eosio_account,                  
                    memo: mantisnft_hashtoverify
                }
            ,
        }]
        }, {
        blocksBehind: 3,
        expireSeconds: 30
        });
      
    } catch(e) {
       
    }
   

} // verify_action_waxcloud



//
// Action for claimdropbox-claim
//
async function claimdropbox_claim_waxcloud( var_recipient, var_dropid )
{

                    
  try {
        const result = await waxcloud.api.transact({
        actions: [
        {
            account: 'claimdropbox',
            name: 'claim',
            authorization: [{
                           actor: eosio_account,
                           permission: 'active',            
            }],
            data: {
                  recipient: var_recipient,                  
                  dropid: var_dropid
                  }
            ,
        }]
        }, {
           blocksBehind: 3,
           expireSeconds: 30
           });
      
    } catch(e) {       
               }            
            
} // claimdropbox_claim_waxcloud






 
<?php
/*
Plugin Name: mantisnft
Plugin URI: http://www.zen-systems.de
Description: EOSIO tools for wordpress und NFT's. Contact us per e-mail to sven.pohl@zen-systems.de
Version: 0.0.4
Author: Sven Pohl
Author URI: http://www.zen-systems.de
*/

define("MANTISNFT_VERSION","0.0.4");

/*
V.0.0.2 - 26.jun.2021 - Add Schema
V.0.0.3 - 26.jun.2021 - Bugfixing login (gethash / verify-hash)
V.0.0.4 - 29.jun.2021 - xxx
*/



register_activation_hook( __FILE__, 'mantisnft_activate' );

function mantisnft_activate() 
{
global $wpdb;
 
$mantisnft_nodeurl        = get_option('mantisnft_nodeurl');
$mantisnft_appname        = get_option('mantisnft_appname');
$mantisnft_history        = get_option('mantisnft_history');
$mantisnft_atomic_api     = get_option('mantisnft_atomic_api');
$mantisnft_gateway_ipfs   = get_option('mantisnft_gateway_ipfs');
$mantisnft_no_nft_message = get_option('mantisnft_no_nft_message');


if ( $mantisnft_appname        == "" ) $mantisnft_appname        = strtolower( get_bloginfo( 'name' ) );
if ( $mantisnft_nodeurl        == "" ) $mantisnft_nodeurl        = "https://wax.greymass.com";
if ( $mantisnft_history        == "" ) $mantisnft_history        = "https://wax.cryptolions.io/v2";
if ( $mantisnft_atomic_api     == "" ) $mantisnft_atomic_api     = "https://wax.api.atomicassets.io";
if ( $mantisnft_gateway_ipfs   == "" ) $mantisnft_gateway_ipfs   = "https://gateway.pinata.cloud/ipfs";
if ( $mantisnft_no_nft_message == "" ) $mantisnft_no_nft_message = "No NFT found!";




update_option('mantisnft_appname'       ,$mantisnft_appname);
update_option('mantisnft_nodeurl'       ,$mantisnft_nodeurl);
update_option('mantisnft_history'       ,$mantisnft_history);
update_option('mantisnft_atomic_api'    ,$mantisnft_atomic_api);
update_option('mantisnft_gateway_ipfs'  ,$mantisnft_gateway_ipfs);
update_option('mantisnft_no_nft_message',$mantisnft_no_nft_message);

 

    



//
// Database ----------------------
//

$table_mantisnft_account         = $wpdb->prefix . "mantisnft_account";

 


//
// table_eosmantis_account
//
$rows = $wpdb->get_results( "show tables like '".$table_mantisnft_account."';" );
$size = count($rows);

$GEFUNDEN = 0;
if ($size > 0)
   {
   $GEFUNDEN = 1;
   } else
    	{
    	$GEFUNDEN = 0;
    	}


////////////////////////////
//// Tabelle neu anlegen
////////////////////////////
if ($GEFUNDEN == 0)
   {
   $wpdb->query( "create table ".$table_mantisnft_account." (id int primary key not null );" );  
   $wpdb->query( "alter  table ".$table_mantisnft_account." add account    VARCHAR(20);" );
   $wpdb->query( "alter  table ".$table_mantisnft_account." add hash       VARCHAR(255);" );
   $wpdb->query( "alter  table ".$table_mantisnft_account." add verified     int;" );
   // 
   $wpdb->query( "alter  table ".$table_mantisnft_account." add veri_time   datetime;" );
   } //// if ($GEFUNDEN == 0)   	 


} // eiosiomantis_activate






//////////////////////////////
//// Plugin-CSS laden
//////////////////////////////
add_action('wp_print_styles', 'mantisnft_plugin_load');

 
 
 
 
 
function mantisnft_plugin_load()
{

 

$csslink = "\n<link rel='stylesheet' href='" .get_option( 'siteurl' ) . '/'  .PLUGINDIR ."/mantisnft/css/style.css'>\n";
echo $csslink;


// ANCHOR ---
$javalink = '<script src="https://unpkg.com/anchor-link@next"></script>';
echo $javalink;

$javalink = '<script src="https://unpkg.com/anchor-link-browser-transport@next"></script>';
echo $javalink;

$js = "
<script>
      const transport = new AnchorLinkBrowserTransport()
      const link = new AnchorLink({
        chains: [{
        
          chainId: '1064487b3cd1a897ce03ae5b6a865651747e2e152090f99c1d19d44e01aea5a4',
          nodeUrl: 'https://wax.greymass.com'
        }],
        transport
      })

      </script>
";
echo $js;



 
$javalink = "\n<script src='" .get_option( 'siteurl' ) . '/'  .PLUGINDIR ."/mantisnft/js/waxjs.js' type='text/javascript'></script>\n";
echo $javalink;


$javalink = "\n<script src='" .get_option( 'siteurl' ) . '/'  .PLUGINDIR ."/mantisnft/js/waxcloud.js' type='text/javascript'></script>\n";
echo $javalink;

// WAX-Cloud ---
$javalink = "\n<script src='" .get_option( 'siteurl' ) . '/'  .PLUGINDIR ."/mantisnft/js/anchor.js' type='text/javascript'></script>\n";
echo $javalink;
 
 

// General
$javalink = "\n<script src='" .get_option( 'siteurl' ) . '/'  .PLUGINDIR ."/mantisnft/js/mantisnft.js' type='text/javascript'></script>\n";
echo $javalink;


 
 
} // function mantisnft_plugin_load()



// 
// Backend -----------------------
//

 

 
 
////////////////////////////////////////////////////////////////
////
//// Erweitertes- Page-Menu
////
////////////////////////////////////////////////////////////////

 
add_action( 'add_meta_boxes', 'mantisnft_add_custom_box' );
add_action( 'add_meta_boxes_page', 'mantisnft_add_custom_box' );
add_action( 'save_post', 'mantisnft_save_postdata' );

 
////////////////////////////////
////
//// @brief 
////
////////////////////////////////
function mantisnft_add_custom_box() 
{
    add_meta_box( 
        'myplugin_sectionid2',
        __( 'MantisNFT', 'mantisnft_textdomain' ),
        'mantisnft_inner_custom_box',
        'post' 
    );

  
    
    add_meta_box(
       'myplugin_sectionid',
        __( 'MantisNFT', 'mantisnft_textdomain' ),
        'mantisnft_inner_custom_box',
        'page' 
    );

    add_meta_box(
 'myplugin_sectionid',
        __( 'MantisNFT', 'mantisnft_textdomain' ),
        'mantisnft_inner_custom_box',
        'full-width'
    );
    
     add_meta_box( 
        'myplugin_sectionid3',
        'MantisNFT',
        'mantisnft_inner_custom_box',
        'post',
        'normal',
        'high' 
    );
    
} //// sp_app_add_custom_box







 
function mantisnft_inner_custom_box( $post ) 
{

  // Use nonce for verification
  wp_nonce_field( plugin_basename( __FILE__ ), 'mantisnft_noncename' );


  $post_id = get_the_ID();

  $mantisnft_page_shortcode     = get_post_meta($post_id , 'mantisnft_page_shortcode', true); 
 
 
print("<label>");

if ( $mantisnft_page_shortcode == 'on')
   print("<input type='checkbox' name='mantisnft_page_shortcode' checked style='' value='on'>"); else
   print("<input type='checkbox' name='mantisnft_page_shortcode'         style='' value='on'>"); 

print(" <strong>include EOSIO resources (css/javascript) for this page</strong> ");


print("</label><br>");
print("<br>");

	  
} //// mantisnft_inner_custom_box



 
function mantisnft_save_postdata( $post_id ) 
{
  
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
      return;

   

  if ( !wp_verify_nonce( $_POST['mantisnft_noncename'], plugin_basename( __FILE__ ) ) )
      return;

  
  // Check permissions
  if ( 'page' == $_POST['post_type'] || 'post' == $_POST['post_type'] ) 
  {
    if ( !current_user_can( 'edit_page', $post_id ) )
        return;
  }
  else
  {
    if ( !current_user_can( 'edit_post', $post_id ) )
        return;
  }
  // OK, we're authenticated: we need to find and save the data
  $mantisnft_page_shortcode = $_REQUEST['mantisnft_page_shortcode']; 
  update_post_meta($post_id, 'mantisnft_page_shortcode', $mantisnft_page_shortcode); 
  
 
} /// sp_ap_save_postdata

 
////////////////////////////////////////////////////////////////
////
//// ENDE - extended page-menu
////
////////////////////////////////////////////////////////////////

 
// 
// Content-Filter --------------------------------
//
add_filter( 'the_content', 'mantisnft_content_filter', 1 );
 
function mantisnft_content_filter( $content ) 
{

$post_id = get_the_ID();
$mantisnft_page_shortcode     = get_post_meta($post_id , 'mantisnft_page_shortcode', true); 
 
 

$postcontent = 
"
<script>
mantisnft_thread();
mantisnft_wallet_autologin();
</script>
";

$content .= $postcontent;

return $content;

} // mantisnft_content_filter



 

// 
// Admin-Panel ---------------------------------
//

 

//////////////////////////////
//// Admin menu
//////////////////////////////
add_action('admin_menu', 'mantisnft_admin_menu');

///////////////////////////////////////////////////////////////////
// make the options function is the admin option page
///////////////////////////////////////////////////////////////////
function mantisnft_admin_menu() 
{
  add_options_page(  'mantisnft Einstellungen', 
            'Mantis NFT', 
            8, 
            __FILE__, 
            'mantisnft_adminpanel');
} //// mantisnft_admin_menu




/////////////////////////////////////////////////////////////////
//  This code is run on the admin options page for this plugin
/////////////////////////////////////////////////////////////////
function mantisnft_adminpanel() 
{
global $wpdb;

 
print("<br>");
print("<h3>Mantis NFT - Configuration</h3>");
print("<small>Version: ".MANTISNFT_VERSION."</small><br>");


print("Github <a href='https://github.com/svenpohl' target='_blank'>https://github.com/svenpohl</a> | e-mail <a href='mailto:sven.pohl@zen-systems.de' target='_blank'>sven.pohl@zen-systems.de</a> | donation  <a href='https://bloks.io/account/mantismantis' target='_blank'>mantismantis</a> <br>");
print("<br>");

print("Powered by <a href='https://www.xuso.de' target='_blank'>XUSO NFT's</a> <a href='https://wax.atomichub.io/explorer/collection/xusoxusoxuso' target='_blank'>XUSO on atomichub.io</a> <br>"); 
print("<br>");


print("<br>");
print("<br>");
 
$mantisnft_nodeurl        = get_option('mantisnft_nodeurl');
$mantisnft_appname        = get_option('mantisnft_appname');
$mantisnft_history        = get_option('mantisnft_history');
$mantisnft_atomic_api     = get_option('mantisnft_atomic_api');
$mantisnft_gateway_ipfs   = get_option('mantisnft_gateway_ipfs');
$mantisnft_no_nft_message = get_option('mantisnft_no_nft_message');

//mantisnft_atomic_api

//
// Save
//
if(isset($_REQUEST['submit_mantisnft']))
  {
 // $eosiomantis_chainid             = trim($_REQUEST["eosiomantis_chainid"]);
  $mantisnft_nodeurl             = trim($_REQUEST["mantisnft_nodeurl"]);
  $mantisnft_appname             = trim($_REQUEST["mantisnft_appname"]);
  $mantisnft_history             = trim($_REQUEST["mantisnft_history"]);
  $mantisnft_atomic_api          = trim($_REQUEST["mantisnft_atomic_api"]);
  $mantisnft_gateway_ipfs        = trim($_REQUEST["mantisnft_gateway_ipfs"]);
  $mantisnft_no_nft_message      = trim($_REQUEST["mantisnft_no_nft_message"]);
    
  update_option('mantisnft_nodeurl',$mantisnft_nodeurl);
  update_option('mantisnft_appname',$mantisnft_appname);
  update_option('mantisnft_history',$mantisnft_history);
  update_option('mantisnft_atomic_api',$mantisnft_atomic_api);
  update_option('mantisnft_gateway_ipfs',$mantisnft_gateway_ipfs);
  update_option('mantisnft_no_nft_message',$mantisnft_no_nft_message);
 
  } //// submit_mantisnft
  
  
  
$mantisnft_nodeurl        = get_option('mantisnft_nodeurl');
$mantisnft_appname        = get_option('mantisnft_appname');
$mantisnft_history        = get_option('mantisnft_history');
$mantisnft_atomic_api     = get_option('mantisnft_atomic_api');
$mantisnft_gateway_ipfs   = get_option('mantisnft_gateway_ipfs');
$mantisnft_no_nft_message = get_option('mantisnft_no_nft_message');




 

print("
<form method='post' action=''>
<br>


<br>
<strong>Node URL ( Example: https://wax.greymass.com ):</strong><br>
<input name='mantisnft_nodeurl' style='width: 600px;' value='".$mantisnft_nodeurl."' ><br>

<br>
<strong>App-ID: (Your wallet will identify your App by this ID)</strong><br>
<input name='mantisnft_appname' style='width: 600px;' value='".$mantisnft_appname."' ><br>

<br>  
<strong>History-Node: ( Example: https://wax.cryptolions.io/v2 )</strong><br>
<input name='mantisnft_history' style='width: 600px;' value='".$mantisnft_history."' ><br>


<br>  
<strong>Atomicassets-API: ( Example: https://wax.api.atomicassets.io )</strong><br>
<input name='mantisnft_history' style='width: 600px;' value='".$mantisnft_atomic_api."' ><br>

<br>  
<strong>Gateway IPFS: ( Example: https://gateway.pinata.cloud/ipfs )</strong><br>
<input name='mantisnft_gateway_ipfs' style='width: 600px;' value='".$mantisnft_gateway_ipfs."' ><br>



<br>  
<hr>  
<strong>No NFT-Message</strong><br>
<input name='mantisnft_no_nft_message' style='width: 600px;' value='".$mantisnft_no_nft_message."' ><br>




<br>
<br>
");



 

print("<br>");


print("
<p class='submit'>
<input type='submit' class='button-primary' name='submit_mantisnft'
value='Save' />
</p>
</form>
");
 
print("<br><br>"); 

print('
<h2>Examples</h2>
<br>
<strong>Example-Content for your protected KeyNFT - content with wallet-login</strong><br>
<textarea style="width:90%;background:white;" readonly>
[eosio_login]  
[nft_info]<div style="background:#eeeeee;padding:10px;"><strong>This content is protected by a KeyNFT. If you have a XUSO-NFT on your wallet, you can access this area. Please login with your WAX-Account.</strong></div>[/nft_info][nft_content type="collection" collection="xusoxusoxuso" ]
Here is your protected content for your users. Put your greatest stuff ever in this area!
<iframe width="560" height="315" src="https://www.youtube.com/embed/V5xmTSiYvn4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
[/nft_content]
</textarea>

<br>

<br>
<strong>Shortcode [nft_content] for access by having an NFT of the collection "xusoxusoxuso":</strong><br>
<div style="padding:5px;border:1px solid #999999;background:white;width:90%;">
[nft_content type="collection" collection="xusoxusoxuso" ] ...your protected content (with other wordpress-shortcodes maybe) [/nft_content]
</div>
<br>

<br>
<strong>Shortcode [nft_content] for access by having an NFT of the collection "xusoxusoxuso" OR "alien.worlds":</strong><br>
<div style="padding:5px;border:1px solid #999999;background:white;width:90%;">
[nft_content type="collection" collection="xusoxusoxuso;alien.worlds" ] ...your protected content (with other wordpress-shortcodes maybe) [/nft_content]
</div>
<br>

<br>
<strong>Shortcode [nft_content] for access by having an NFT of the template id "60869":</strong><br>
<div style="padding:5px;border:1px solid #999999;background:white;width:90%;">
[nft_content type="template" collection="" template="60869" ] ...your protected content (with other wordpress-shortcodes maybe) [/nft_content]
</div>
<br>

<br>
<strong>Shortcode [nft_content] for access by having an NFT of the template id "60869" OR "113906":</strong><br>
<div style="padding:5px;border:1px solid #999999;background:white;width:90%;">
[nft_content type="template" collection="" template="60869;113906" ] ...your protected content (with other wordpress-shortcodes maybe) [/nft_content]
</div>
<br>

<br>
<strong>Shortcode [nft_content] for access by having an NFT of the asset-id "1099545088338":</strong><br>
<div style="padding:5px;border:1px solid #999999;background:white;width:90%;">
[nft_content type="asset" collection="" template="" asset="1099545088338" ] ...your protected content (with other wordpress-shortcodes maybe) [/nft_content]
</div>
<br>

<br>
<strong>Shortcode [nft_content] for access by having an NFT of the asset-id "1099545088338" OR "1099539110613":</strong><br>
<div style="padding:5px;border:1px solid #999999;background:white;width:90%;">
[nft_content type="asset" collection="" template="" asset="1099545088338;1099539110613" ] ...your protected content (with other wordpress-shortcodes maybe) [/nft_content]
</div>
<br>


<br>
<strong>Shortcode [nft_content] for access by having an NFT of the collection "xusoxusoxuso" AND schema "unique":</strong><br>
<div style="padding:5px;border:1px solid #999999;background:white;width:90%;">
[nft_content type="collection" collection="xusoxusoxuso" schema="unique" ] ...your protected content [/nft_content]
</div>
<br>

<br>
<strong>Keep in mind:</strong><br>
Currently only each of one shortcode [nft_info] and [nft_content] per post is supported. 
<br>


');

} //// eosiomantis_adminpanel



//
// Shortcodes ---------------------------------
//

/////////////////////////////////////////////
////
//// [eosio_login] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_eosio_login') ) 
 {
	function func_eosio_login($atts) 
	{
   
   
    
    $content .= "<div id='eosio_login_area' class=''>";
    
     $content .= "<div class='eosio_login_cloud_button deselect eosio_round'  style=''   >";
      
      $content .= "<div class='eosio_login_left'  style=''  onclick='wallet_login_cloud();'   >";
      $content .= "WAX Cloud Wallet";
      $content .= "</div>";


      $content .= "<a href='https://wallet.wax.io/' target='_blank'>";
       $content .= "<div class='eosio_login_right_cloud'  style=''    >";
       $content .= "&nbsp;";
       $content .= "</div>";
      $content .= "</a>";
      
      $content .= "<div style='clear:both'></div>";
     $content .= "</div>";
 
    
    
     
     $content .= "<div class='eosio_login_anchor_button deselect eosio_round' style=''   >";
    
         
     $content .= "<div class='eosio_login_left'  style=''  onclick='wallet_login_anchor();'   >";
      $content .= "Anchor";
      $content .= "</div>";


      $content .= "<a href='https://greymass.com/anchor/' target='_blank'>";
       $content .= "<div class='eosio_login_right_anchor'  style=''    >";
       $content .= "&nbsp;";
       $content .= "</div>";
      $content .= "</a>";
      
     
     
    $content .= "<div style='clear:both'></div>";
    $content .= "</div>";






 
    $content .= "<div id='eosio_logout_area'  class='eosio_logout_area' style='visibility:hidden;height:0px;'  >";
    
     $content .= "<div id='mantis_accountname_div' class='mantis_accountname_div'  style=''>";
     $content .= "<span id='mantis_accountname' class='mantis_accountname'>accountname</span>";
     $content .= " <span id='mantis_checkmark' class='mantis_checkmark'>&cross;</span>";
     $content .= "</div>";

 
 
     
     $content .= "<div id='mantis_logout_button' class='mantis_logout_button deselect eosio_round' style=''   onclick='mantisnft_wallet_logout();'   >";
     $content .= "Logout ";
       $content .= "<div id='mantis_logout_icon' class='mantis_logout_icon' style=''>&nbsp;</div>";
     $content .= "</div>";

   $content .= "<div style='clear:both'></div>";
   

     $content .= "<div id='mantis_verify' class='mantis_verify deselect eosio_round' onclick='mantisnft_verify()' style='height:0px'>";
     $content .= "Verify";
     $content .= "</div>";

    $content .= "</div>";






    $content .= "</div>";

   $content .= "<div style='clear:both'></div>";
 

     

      


    $mantisnft_url = get_option( 'siteurl' ) . '/'  .PLUGINDIR . "/mantisnft/";
 
        
    $mantisnft_appname        = get_option('mantisnft_appname');
    $mantisnft_atomic_api     = get_option('mantisnft_atomic_api');
    $mantisnft_gateway_ipfs   = get_option('mantisnft_gateway_ipfs');
    $mantisnft_no_nft_message = get_option('mantisnft_no_nft_message');
    
    $mantisnft_post_id = get_the_ID();
        
    $content .= "<script>\n";
    $content .= "mantisnft_url = '"  .$mantisnft_url. "';\n";
    $content .= "mantisnft_appname = '"  .$mantisnft_appname. "';\n";
    $content .= "mantisnft_post_id = '"  .$mantisnft_post_id. "';\n";
    $content .= "mantisnft_atomic_api = '"  .$mantisnft_atomic_api. "';\n";
    $content .= "mantisnft_gateway_ipfs = '"  .$mantisnft_gateway_ipfs. "';\n";
    $content .= "mantisnft_no_nft_message = '"  .$mantisnft_no_nft_message. "';\n";
    $content .= "</script>\n";
    
    
    
 
   
	return $content;
	} //// func_sv_core_css
	
	add_shortcode("eosio_login", "func_eosio_login");
} //// if func_eosio_login


 

 

 
 
 
/////////////////////////////////////////////
////
//// [nft_info] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_nft_info') ) 
 {
	function func_nft_info($atts,  $innercontent = null) 
	{
    $innercontent2 = do_shortcode($innercontent);
    $content = "";    
    $content .= "<div id='nft_info_div' style=''>".$innercontent2."</div>";   
	return $content;
	} //// func_nft_nft_info
	
	add_shortcode("nft_info", "func_nft_info");
} //// if func_nft_info



/////////////////////////////////////////////
////
//// [nft_content] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_nft_content') ) 
 {
	function func_nft_content($atts,  $innercontent = null) 
	{
 
   
    $content = "";   
    $content .= "<div id='nft_content' style=''></div>";


	return $content;
	} //// func_nft_nft_info
	
	add_shortcode("nft_content", "func_nft_content");
} //// if func_nft_content


 // alfalf
 /*
 https://wax.api.atomicassets.io/atomicassets/v1/templates/thewarlord33/151739
 */

/////////////////////////////////////////////
////
//// [nft_show_template] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_nft_show_template') ) 
 {
	function func_nft_show_template($atts) 
	{
 
    $collection = $atts['collection'];
    $tid        = $atts['id'];
    $color      = $atts['color'];
    
    $mantisnft_atomic_api     = get_option('mantisnft_atomic_api');
    $mantisnft_gateway_ipfs   = get_option('mantisnft_gateway_ipfs');    
    
    $url = $mantisnft_atomic_api . "/atomicassets/v1/templates/".$collection."/".$tid;
    
    
    
    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");    			
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 105);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 105);

    $file_contents = curl_exec($ch);
    curl_close($ch);    
 
    $json_array = json_decode($file_contents, true);

 

 

 

   $content .= "url (".$url.") <br>";
   
    $hash = $json_array['data']['immutable_data']['img'];
    $nft_name = $json_array['data']['immutable_data']['name'];
   
    //  https://gateway.pinata.cloud/ipfs/QmdPQpSHnrvj3M3sqAArrvDeVZJEuQsFW5tigN9neacrdS

    
    $content = "";   
//        $content .= "url (".$url.") <br>";
  //        $content .= "hash (".$hash.") <br>";

  //  $content .= "<div id='' style=''>tid: ".$tid."</div>";
    
    
    $nft_img = $mantisnft_gateway_ipfs . "/" . $hash;
    
    /*


    $content .= "<div id=''  style='width:300px;height:300px'>";

     $content .= "<img src='".$nft_img."' class='nft_assetdiv_img'   >";
    $content .= "</div>"; 
         
    
   
*/

    if ($color != "white")
    $content .= "<div id='nft_assetdiv'  class='nft_assetdiv' style=''>"; else
    $content .= "<div id='nft_assetdiv'  class='nft_assetdiv_white' style=''>";  
    
      $content .= "<div class='nft_square'> ";
       $content .= "<div class='nft_content'>";
       //   $content .= "  Hello Fisch!";
       
       $link = "https://wax.atomichub.io/explorer/template/cryptopuppyz/".$tid;
       $content .= "<a href='".$link."' target='_blank'>";
       $content .= "<img src='".$nft_img."' class='nft_assetdiv_img'   >";
       $content .= "</a>";

       $content .= " </div>";
      $content .= "</div>";
      
 //$content .= "<div style='clear:both'></div>";
       

     $collection_link = "<a href='https://wax.atomichub.io/explorer/collection/".$collection."' target='_blank' style='text-decoration:none'>".$collection."</a>";   

     if ($color != "white")
     $content .= "<div class='nft_assetdiv_collection'>".$collection_link  . "</div >"; else
     $content .= "<div class='nft_assetdiv_collection_white'>".$collection_link  . "</div >";
        
     $content .= "<span class='nft_assetdiv_name'>".$nft_name  . "</span><br>";
      

    $content .= "</div>"; // nft_assetdiv
    
    
/*
<div class="square">
  <div class="content">
    Hello!
  </div>
</div>
CSS
.square {
  position: relative;
  width: 50%;
}

.square:after {
  content: "";
  display: block;
  padding-bottom: 100%;
}

.content {
  position: absolute;
  width: 100%;
  height: 100%;
}
*/

	return $content;
	} //// func_nft_show_template
	
	add_shortcode("nft_show_template", "func_nft_show_template");
} //// if func_nft_content



/////////////////////////////////////////////
////
//// mantisnft_get_pc_info
////
/////////////////////////////////////////////
function mantisnft_get_pc_info( $postid )
{

$postcontent = get_post_field('post_content', $postid);
$l = strlen($postcontent);
   
   
   
unset($thearray);
    
// First tag
$thearray['start1'] = strpos( $postcontent , "[nft_content" );    
$thearray['end1'] = $thearray['start1'];
while ( $postcontent[ $thearray['end1'] ] != "]") $thearray['end1']++;
$thearray['length1'] = $thearray['end1'] - $thearray['start1'] +1 ;


// Second tag
$thearray['start2'] = strpos( $postcontent , "[/nft_content]" );
$thearray['end2'] = $thearray['start2'];
while ( $postcontent[ $thearray['end2'] ] != "]") $thearray['end2']++;
$thearray['length2'] = $thearray['end2'] - $thearray['start2'] + 1;
        
    
$tag1 = substr ( $postcontent , $thearray['start1'], $thearray['length1'] );
$tag2 = substr ( $postcontent , $thearray['start2'], $thearray['length2'] );

$thearray['tag1'] = $tag1;
$thearray['tag2'] = $tag2;

$thearray['innerlength'] = $thearray['start2'] - $thearray['end1']-1;
    
        
$shortcode_atts = shortcode_parse_atts( $thearray['tag1'] ); 
$thearray['shortcode_atts'] = $shortcode_atts;
    
$innercontent = substr ( $postcontent , $thearray['end1']+1, $thearray['innerlength'] );        
$thearray['innercontent'] = $innercontent;
      
return( $thearray );
} // mantisnft_get_pc_info()


 

?>
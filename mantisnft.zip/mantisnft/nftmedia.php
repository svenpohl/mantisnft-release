<?php

$jsonstring = trim(file_get_contents('php://input'));

$thedata = json_decode($jsonstring,true);
$assetid = $thedata['assetid'];



$url = "https://wax.api.atomicassets.io/atomicassets/v1/assets/".$assetid;


    
    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");    			
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 105);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 105);

    $file_contents = curl_exec($ch);
    curl_close($ch);    
 
    $json_array = json_decode($file_contents, true);
    
    
  $hash_img = $json_array['data']['template']['immutable_data']['img'];
  $hash_video = $json_array['data']['template']['immutable_data']['video'];
      

if ($hash_img != "")
   {
   $imgbuffer = "<img src='https://gateway.pinata.cloud/ipfs/".$hash_img."/'>";
   }

if ($hash_video != "")
   {
   $imgbuffer = "<div style='text-align:center;border:1px solid #ffffff;background:#efefef'><br>Video-thumbnail currently not supportet<br><br></div>";
   }

print($imgbuffer);



?>
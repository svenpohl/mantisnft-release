<?php
include "../../../wp-load.php";

 
header('Content-Type: application/json');
global $wpdb;

date_default_timezone_set('UTC');

$cmd = $_REQUEST['cmd'];


if ($cmd == 'isverified')
{

$jsonstring = trim(file_get_contents('php://input'));

$thedata = json_decode($jsonstring,true);
$account = $thedata['account'];
$app     = $thedata['app'];
$ip= $_SERVER['REMOTE_ADDR'] ; 

$seedtohash = $account .'+'.$ip.'+'.$app;

$hash = hash("sha256",$seedtohash);


 
$data = "{ \"hash\":\"".$hash."\"   }";
 

 
echo $data;


 
exit(0);
} // if ($cmd == 'isverified')





// Check, if transaction does exist
if ($cmd == 'checktx')
{
$mantisnft_history = get_option('mantisnft_history');

$jsonstring = trim(file_get_contents('php://input'));

$thedata         = json_decode($jsonstring,true);
$tocheck_account = $thedata['account'];
$app             = $thedata['app'];
$ip              = $_SERVER['REMOTE_ADDR'] ; 

$seedtohash = $tocheck_account .'+'.$ip.'+'.$app;
$hash = hash("sha256",$seedtohash);


// ---
// funktion checktx
// ---
$retarray = checktx($tocheck_account,$hash);

$checked = $retarray['checked'];
$debug   = $retarray['debug'] . " (by a function)";
 
 
 
 
$data = "{ \"hash\":\"".$hash."\" ,   \"debug\":\"".$debug."\" ,    \"checked\":\"".$checked."\"   }";  
 

 
echo $data;


 
exit(0);
} // if ($cmd == 'checktx')




if ($cmd == 'checkasset')
{
$jsonstring = trim(file_get_contents('php://input'));

$thedata = json_decode($jsonstring,true);
$tocheck_account       = $thedata['account'];

$tocheck_type          = $thedata['type'];
$tocheck_collection    = $thedata['collection'];
$tocheck_template      = $thedata['template'];
$tocheck_asset         = $thedata['asset'];


 
$tocheck = worker_checkasset( $tocheck_account, $tocheck_type, $tocheck_collection, $tocheck_template, $tocheck_asset );
 

$size = 42;
 
 
$data = "{ \"return\":\"".$tocheck."\" ,  \"size\":\"".$size."\"  }";
 

//echo json_encode($data);
echo $data;


 
exit(0);
} // if ($cmd == 'checkasset')





if ($cmd == 'loadcontent')
{

$jsonstring = trim(file_get_contents('php://input'));

$thedata = json_decode($jsonstring,true);

$tocheck_postid       = $thedata['postid'];
$tocheck_account      = $thedata['account'];
$app                  = $thedata['app'];
$ip                   = $_SERVER['REMOTE_ADDR'] ; 

$seedtohash = $tocheck_account .'+'.$ip.'+'.$app;
$hash = hash("sha256",$seedtohash);


// Is verified?
$retarray = checktx($tocheck_account,$hash);

$checked = $retarray['checked'];
$debug   = $retarray['debug'] . " (by a function)";

// -> Exit if not verified
if ($checked != 1)
   {
   echo "{error_verified}";
   exit(0);
   }



// Check Shortcodes
$thearray = mantisnft_get_pc_info( $tocheck_postid );
 
 
$tocheck_type       = $thearray['shortcode_atts']['type'];
$tocheck_collection = $thearray['shortcode_atts']['collection'];
$tocheck_template   = $thearray['shortcode_atts']['template'];
$tocheck_asset      = $thearray['shortcode_atts']['asset'];

$innercontent = $thearray['innercontent'];
 
 
// Check-Asset
$checked = worker_checkasset( $tocheck_account, $tocheck_type, $tocheck_collection, $tocheck_template, $tocheck_asset );

if ($checked != 1)
   {
   echo "{error_nft}";
   exit(0);
   }
   
 
 
 
 $tocheck = "postid xux: ".$tocheck_postid ." colection:(".$tocheck_collection .")" . " innercontent:(".$innercontent .")" .  time();
 $size = 34;
 
 

$thecontent = do_shortcode($innercontent);
print($thecontent);
 
exit(0);
} // if ($cmd == 'loadcontent')

 
 


$ip= $_SERVER['REMOTE_ADDR'] ; 

$seed = $ip . 'xusoxuso';

$content = "WORKERCONTENT (".$wpdb->prefix.") [".$seed."]" . time();

 
 

$content2 =  do_shortcode( '[testred] ABC <span style="color:#ff00ff;">CX</span>    [testblue param="alf;1234;Mumpfli"]   ' );
$content .= $content2;

print($content);

  
//
// checktx
//
function checktx($account,$hash)
{
global $wpdb;
unset($retarray);


if ($account == "") 
   {
   $retarray['checked'] = 0;
   return($retarray);
   }

$mantisnft_history = get_option('mantisnft_history');

$tocheck_account = $account;
$tocheck_memo = $hash;

//
// remove < 12h
//
$table_mantisnft_account         = $wpdb->prefix . "mantisnft_account";

$ts = time() - (12*60*60); 
$date_old = date( 'Y-m-d H:i:s', $ts); 
 
$sql = "delete from ".$table_mantisnft_account." where veri_time < '".$date_old."' ";
 $wpdb->query( $sql  );



 

//
// Is in DB?
//
 

$query = "select id from ".$table_mantisnft_account." where account='".$tocheck_account."' AND hash='".$tocheck_memo."' AND verified='1' ;";
$theid = $wpdb->get_var( $query );
 
// If found then return
if ($theid != "")
   {
   $checked = 1;
   $debug = " From DB2 " . $ret2['checked'];
  

$retarray['debug'] = $debug;
$retarray['checked'] = $checked;

return($retarray);
   }


//
// Scan in Blockchain and create DB-entry
//
// Go 12 hours back in time
$ts = time() - (12*60*60); 


$start = date("Y-m-d\TH:i:s.000",$ts);



$url = $mantisnft_history . "/history/get_actions?account=".$tocheck_account."&after=".$start."Z";




// To check...
$checked = 0;

$data_string = json_encode($data);

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");    			
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 105);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 105);

$file_contents = curl_exec($ch);
curl_close($ch);    
 
$json_array = json_decode($file_contents, true);

 

 

$size = count( $json_array['actions'] );
$actions = $size;

for ($i=0;$i<$size; $i++)
    {
    $account = $json_array['actions'][$i]['act']['account'];
    $name    = $json_array['actions'][$i]['act']['name'];
    $actor   = $json_array['actions'][$i]['act']['authorization'][0]['actor'];
    $signer  = $json_array['actions'][$i]['act']['data']['signer'];
    $memo    = $json_array['actions'][$i]['act']['data']['memo'];
    
    
    if ( $tocheck_memo == $memo )
       {
       $checked = 1;
       $i=$size;
       }
    
    } // for $i..

//
// DB entry 
//
if ($checked == 1)
   {

$query = "select max(id) from ".$table_mantisnft_account.";";
$maxid = 0;
$maxid = $wpdb->get_var( $query );
$maxid++; 

      
$query = "insert into ".$table_mantisnft_account." (id) values ('".$maxid."');";
$wpdb->query( $query );

$query = "update ".$table_mantisnft_account." set account='".$tocheck_account ."' where id='".$maxid."';";
$wpdb->query( $query );

$query = "update ".$table_mantisnft_account." set hash='".$tocheck_memo ."' where id='".$maxid."';";
$wpdb->query( $query );

$query = "update ".$table_mantisnft_account." set verified='1' where id='".$maxid."';";
$wpdb->query( $query );

$veri_time = date("Y-m-d\TH:i:s.000");
$query = "update ".$table_mantisnft_account." set veri_time='".$veri_time ."' where id='".$maxid."';";
$wpdb->query( $query );


$debug = " (ADD DB) ";

   } // if ($checked == 1)

 
 


$retarray['checked'] = $checked;

return($retarray);
} // checktx()


//
// worker_checkasset()
//
function worker_checkasset( $tocheck_account, $tocheck_type, $tocheck_collection, $tocheck_template, $tocheck_asset )
{

 

$tocheck            = 0;


 
$mantisnft_nodeurl = get_option('mantisnft_nodeurl');

 
$url = $mantisnft_nodeurl."/v1/chain/get_table_rows";
 

 
$data_string = '{"table":"assets","scope":"'.$tocheck_account.'","code":"atomicassets","limit":1000,"json":"true"}';
 
$ch = curl_init($url);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");    			
 curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$timeout = 50;
curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);

$file_contents = curl_exec($ch);
curl_close($ch);    
 
$json_array = json_decode($file_contents, true);

 


$size = count( $json_array['rows']);
 



$tocheck_collection_array = explode(";",$tocheck_collection);
$tocheck_template_array   = explode(";",$tocheck_template);  
$tocheck_asset_array      = explode(";",$tocheck_asset);  
 

 

for ($i=0; $i<$size; $i++)
    {
    $col = $json_array['rows'][$i]['collection_name'];
    $tid = $json_array['rows'][$i]['template_id'];
    $ass = $json_array['rows'][$i]['asset_id'];
  
  
    
    if ($tocheck_type == "collection")
       {       
       if ( in_array( $col, $tocheck_collection_array) )
          {
          $tocheck = 1;
          $i = $size;
          }
       } // if ($tocheck_type == "collection")

    if ($tocheck_type == "template")
       {       
       if ( in_array( $tid, $tocheck_template_array) )
          {
          $tocheck = 1;
          $i = $size;
          }
       } // if ($tocheck_type == "collection")

    if ($tocheck_type == "asset")
       {       
       if ( in_array( $ass, $tocheck_asset_array) )
          {
          $tocheck = 1;
          $i = $size;
          }
       } // if ($tocheck_type == "collection")

    
    } // for i...



return( $tocheck );
}


?>